public class pattern3 {

	public static void main(String[] args)
	{
		int n=4;

		for(int i=1; i<=n; i++)
		{
			//star
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			//space
			int sp=2*(n-i);
			for(int j=1; j<=sp; j++)
			{
				System.out.print(" ");
			}
			//star
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		//for second half butterfly
		for(int i=n; i>=1; i--)
		{
			//star
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			//space
			int sp=2*(n-i);
			for(int j=1; j<=sp; j++)
			{
				System.out.print(" ");
			}
			//star
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}
	}
}