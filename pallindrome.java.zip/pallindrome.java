import java.util.*;

public class pallindrome
{
	public static void main(String[] args) {
    
    Scanner sc=new Scanner(System.in);
    
    String str=sc.next();
    String rev="";
    for(int i=str.length()-1;i>=0;i--)
    {
        rev+=str.charAt(i);
    }
    
    if(str.equals(rev))
    {
        System.out.print("Pallindrome");
    
	}
	else
	System.out.print("Not pallindrome");
}
}