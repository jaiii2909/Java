import java.util.*;

public class array2
{
	public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
	System.out.print("Rows:");
	int row=sc.nextInt();
	System.out.print("Columns:");
	int column=sc.nextInt();
	System.out.print("elements:");
	
	int [][] arr=new int[row][column];
	
	for(int i=0;i<row;i++)
	{
	    for(int j=0;j<column;j++)
	    {
	        arr[i][j]=sc.nextInt();
	    }
	}
	
	System.out.print("Search element:");
	int Search=sc.nextInt();
	
	for(int i=0;i<row;i++)
	{
	    for(int j=0;j<column;j++)
	    {
	        if(arr[i][j]==Search)
	        {
	            System.out.print("Present at:"+(i+1)+","+(j+1));
	            break;
	        }
	    }
	}
	}
}