import java.io.*;
import java.util.*;

public class plac5 {
    
    public static int difference(int n,int m)
    {
        int div=0;
        int ndiv=0;
        int diff;
        for(int i=1;i<=m;i++)
        {
            if(i%n==0)
            {
                div=div+i;
            }
            else
            {
                ndiv= ndiv+i;
            }
        }
        diff=ndiv-div;
        return diff;
        
    }

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc=new Scanner (System.in);
        int n=sc.nextInt();
        int m=sc.nextInt();
        
        System.out.print(difference(n,m));
    }
}