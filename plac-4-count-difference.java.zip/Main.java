import java.io.*;
import java.util.*;

public class Plac4 {

    public static int findCount(int n,int arr[],int num,int diff)
    {
        int count=0;
        int temp=0;
        for(int i=0;i<n;i++)
        {   
            temp=Math.abs(arr[i]-num);
            if(temp<=diff)
            {
                count++;
            }   
            
        }
        if(count==0)
        {
            return -1;
        }
        else
            return count;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] arr=new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        int num=sc.nextInt();
        int diff=sc.nextInt();
        
        int r=findCount(n,arr,num,diff);
        System.out.print(r); 
    }
}