import java.util.*;

public class array1
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.print("Size:");
	int size=sc.nextInt();
	int[] arr=new int[size];
	
	for(int i=0;i<size;i++)
	{
	    arr[i]=sc.nextInt();
	}
	System.out.println("search element:");
	int search=sc.nextInt();
	
	for(int i=0;i<size;i++)
	{
	    if(arr[i]==search)
	    {
	        System.out.print("Element present at:"+i);
	        break;
	    }
	    
	}
	
	}
}