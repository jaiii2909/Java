/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class pattern3
{
	public static void main(String[] args) {
	
	int n=5;
	for(int i=n;i>=1;i--)
	{
	    for(int j=i-1;j>=1;j--)
	    {
	        System.out.print(" ");
	    }
	    
	    for(int j=1;j<=5;j++)
	    {
	        System.out.print("*");
	    }
	    
	    System.out.println();
	}
	}
}