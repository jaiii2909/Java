import java.io.*;
import java.util.*;

public class series2{

    public static void main(String[] args) {
    
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        
        int [] arr=new int [100];
        arr[0]=1;
        arr[1]=1;
        for(int i=0;i<n-2;i++)
        {
            if(i%2==0)
            {
                arr[i+2]=arr[i]*2;
            }
            else
            {
                arr[i+2]=arr[i]*3;
            }
        }
       System.out.print("Complete series:");
       for(int i=0;i<n;i++)
       {
           System.out.print(arr[i]+" ");
       }
       
            System.out.print("\nNth term:"+arr[n-1]);
        
    }
}