import java.util.*;

public class string1
{
	public static void main(String[] args) {
	    
	Scanner sc=new Scanner(System.in);
	
	System.out.print("Size:");
	int size=sc.nextInt();
	
	int totalen=0;
	System.out.println("Enter Strings:");
	String[] arr=new String [size];
	for(int i=0;i<size;i++)
	{
	    arr[i]=sc.next();
	    totalen += arr[i].length();
	}
	
	System.out.println("Combined length of string="+totalen);
	

	}
}