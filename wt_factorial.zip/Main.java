import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Solution {
    public static int fact(int num) {
        int tmp=1;
        for(int i=num;i>=1;i--)
        {
            tmp=tmp*i;
        }
        return tmp;
    }


public static void main(String[] args) {

    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int res=fact(n);
    System.out.print(res);
    
    
    }
}
