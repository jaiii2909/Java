import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;


public class Solution {
 
    public static int findPower(int X, int Y) 
    {
        int tmp=1;
        for(int i=1;i<=Y;i++)
        {
            tmp=X*tmp;
        }
        return tmp;
    }
    
   public static void main(String[] args){
       Scanner sc=new Scanner(System.in);
       int m=sc.nextInt();
       int n=sc.nextInt();
       int res=findPower(m,n);
       System.out.print(res);
   }
}
